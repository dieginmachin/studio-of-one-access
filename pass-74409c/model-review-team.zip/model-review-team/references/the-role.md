# The designer who models the AI

A new kind of design job is showing up: designing what the model makes, not only what the designer makes. In plain words, the work is:

1. **Write the heuristics.** What good looks like, as rules a model can follow and a person can check.
2. **Build the test.** A fair set of briefs and designs, picked before the results come in.
3. **Judge the output.** Review AI-made designs against the rules, the same way you'd review a junior designer.
4. **Check the checker.** When an AI reviews too, measure how often it agrees with a human and what it misses.
5. **Feed it back.** Feedback that happens twice becomes a rule. The rulebook is how the model gets better at your taste.

Teams 01 (Heuristics) and 03 (Model Review) do steps 1 to 5 on your own work.

Diego learned this on paid client work: Claude reading Figma frames through Figma MCP, comparing each design to a brand's approved emails and rules, leaving comments a human accepts or rejects. That loop was still in testing in October 2026. This team is how he measures it.
