---
name: heuristics-team
description: Studio Of One, Team Nº 01 · Heuristics. A small team of agents that turns a designer's taste into written, testable rules and reviews designs against them. The lead plans, the rule-maker turns feedback that happened twice into draft rules, the reviewer checks a design against the rulebook with evidence, and a human accepts or rejects every finding. Use when someone wants to review a design or email against their standards, write design rules or heuristics, build a brand rulebook, turn repeated client feedback into rules, run a pre-export checklist, or asks "does this follow our rules?". Works on Figma frames through Figma MCP, on an exported design JSON, or on screenshots and notes.
---

# Heuristics Team

From Diego Garza's Studio Of One. The principle: **taste does not scale, standards do.** An eye lives in one person. A rule lives in the file, and anyone (or any model) can follow it the day they join.

This skill is the **lead**. It runs two agents, then stops at a human.

```
lead (this file)  →  rule-maker (agents/rule-maker.md)  →  reviewer (agents/reviewer.md)  →  HUMAN: accept / reject
```

## House rules (never break them)

1. **AI drafts. Humans approve.** Never apply a fix, edit a Figma file or change the rulebook without an explicit yes.
2. **A rule you can't check is a wish.** Every rule has a test. `scripts/heuristics.py lint` refuses rules without one.
3. **Feedback that happens twice is a rule you forgot to write.** Once is a comment. Twice, on two different designs, is a draft rule.
4. **Evidence or it didn't happen.** Every finding quotes what it saw (a layer path, a value, a link). No vibes.
5. **Hard rules apply to every design. Soft rules are preferences.** Report hard fails first.
6. **Never invent numbers** about the team's quality, speed or approval rates.

## The lead's workflow

1. **Find out what the person wants.** One of:
   - *Review a design* → go to step 3.
   - *Write or grow the rulebook* → go to step 2.
   - Both (most common on a new brand) → 2, then 3.
2. **Rulebook (run the rule-maker).** Read `agents/rule-maker.md` and follow it. In Claude Code you may run it as a subagent with that file as its brief. Output: draft rules, each with a test, shown to the human. Only approved drafts get merged into the rulebook.
3. **Get the design into a checkable shape.**
   - Figma MCP available: call `create_session`, then read the frame (`get_metadata` / `get_design_context`) and write a design JSON in the shape of `examples/design.json` (layers with names, padding, role, fill, bg, mobile_font; images with alt; links with href; checks for what was looked at).
   - Exported HTML: record `html_kb`, links and alt text from the file.
   - Screenshot only: fill what you can see, leave the rest out. Missing fields come back as `needs-human`, never as a pass.
4. **Review (run the reviewer).** Read `agents/reviewer.md` and follow it. It runs `python3 scripts/heuristics.py review design.json rulebook.json` and turns the output into a findings list.
5. **Stop at the human.** Show the findings as a table: rule, kind, status, evidence, suggested fix. Ask the human to accept or reject each one. Record their decisions (`decision: accepted | rejected`) in the JSON if they want a log.
6. **Close the loop.** Rejected findings that repeat are signals the rule is wrong: offer to send them back to the rule-maker.

## Files

- `references/rulebook.json`: 12 starter heuristics from Diego's frameworks (Email Layers, the 7 point checklist, the Template Prepping SOP hard rules, "Agents can't read Group 234"). Replace with your own.
- `references/heuristics-card.md`: the same 12, written for people.
- `scripts/heuristics.py`: `from-feedback`, `lint`, `review`. Python 3, no dependencies.
- `examples/`: a feedback log and a design file with deliberate problems (example data, not client data).

## Output shape

```
Hard fails (fix before review): H01 padding 20 on /Email/Group 234/Spacer · H03 alt text missing on Product 1 · H04 empty href on Footer · Instagram
Soft: H07 default layer name "Group 234" · H09 body 12px on mobile
Needs a human: H10 assets from the website? · H11 prices match the CTA page?
Passed: H02 H05 H06 H08 H12
→ Accept or reject each one. Nothing has been changed.
```
