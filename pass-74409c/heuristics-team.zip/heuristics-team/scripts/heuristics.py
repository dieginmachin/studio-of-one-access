#!/usr/bin/env python3
"""Team Nº 01 · Heuristics. No dependencies.

  python3 heuristics.py from-feedback FEEDBACK.csv [--min 2]   repeated feedback -> draft rules (JSON)
  python3 heuristics.py lint RULEBOOK.json                    every rule must be testable
  python3 heuristics.py review DESIGN.json RULEBOOK.json      check a design, never edits it

FEEDBACK.csv columns: design, note   (optional: brand, date, who)
DESIGN.json: see examples/design.json. Unknown fields are ignored.
"""
import csv, json, re, sys
from pathlib import Path

CHECKS = {"spacing_in_set", "max_kb", "alt_text", "links", "flag", "layer_names", "contrast", "min_font", "human"}
STOP = set("a an the is are be to of on in at it this that and or for with too very please should could would can its it's".split())
DEFAULT_NAME = re.compile(r"^(group|frame|rectangle|ellipse|vector|image|layer|text|line|component)\s*\d*$", re.I)


# ---------- feedback that happens twice is a rule you forgot to write ----------
def tokens(note):
    words = re.findall(r"[a-z0-9]+", note.lower())
    return {w[:-1] if w.endswith("s") and len(w) > 3 else w for w in words if w not in STOP}


def similar(a, b):
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def from_feedback(rows, min_count=2, threshold=0.5):
    """Cluster notes by word overlap. A cluster seen on min_count different designs becomes a draft rule."""
    clusters = []
    for r in rows:
        note = (r.get("note") or "").strip()
        if not note:
            continue
        t = tokens(note)
        best, score = None, 0.0
        for c in clusters:
            s = similar(t, c["tokens"])
            if s > score:
                best, score = c, s
        if best is not None and score >= threshold:
            best["notes"].append(note)
            best["designs"].add((r.get("design") or "").strip())
            best["tokens"] |= t
        else:
            clusters.append({"tokens": set(t), "notes": [note], "designs": {(r.get("design") or "").strip()}})
    drafts = []
    for c in clusters:
        n = len({d for d in c["designs"] if d})
        if n < min_count:
            continue
        drafts.append({
            "id": f"D{len(drafts) + 1:02d}",
            "statement": c["notes"][0].rstrip(".") + ".",
            "kind": "soft",
            "test": {"check": "human", "question": "TODO: write a yes/no check a stranger could run"},
            "source": f"feedback on {n} designs",
            "evidence": c["notes"][:5],
            "status": "draft: needs a human yes",
        })
    drafts.sort(key=lambda d: -int(d["source"].split()[2]))
    for i, d in enumerate(drafts):
        d["id"] = f"D{i + 1:02d}"
    return drafts


# ---------- a rule you can't check is a wish ----------
def lint(book):
    problems = []
    seen = set()
    for r in book.get("rules", []):
        rid = r.get("id", "?")
        if rid in seen:
            problems.append((rid, "duplicate id"))
        seen.add(rid)
        if not r.get("statement"):
            problems.append((rid, "no statement"))
        if r.get("kind") not in ("hard", "soft"):
            problems.append((rid, "kind must be hard or soft"))
        if not r.get("source"):
            problems.append((rid, "no source: say where the rule came from"))
        t = r.get("test") or {}
        chk = t.get("check")
        if chk not in CHECKS:
            problems.append((rid, f"no test, so it is a wish (check must be one of {sorted(CHECKS)})"))
        elif chk == "human":
            q = t.get("question", "")
            if not q or q.startswith("TODO") or not q.rstrip().endswith("?"):
                problems.append((rid, "human check needs a yes/no question ending in '?'"))
    return problems


# ---------- review ----------
def lum(hexc):
    h = hexc.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    rgb = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    lin = [c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4 for c in rgb]
    return 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2]


def contrast(a, b):
    la, lb = sorted([lum(a), lum(b)], reverse=True)
    return (la + 0.05) / (lb + 0.05)


def walk(layers, path=""):
    for l in layers or []:
        p = f"{path}/{l.get('name', '?')}"
        yield p, l
        yield from walk(l.get("children"), p)


def run_check(r, d):
    t = r["test"]
    chk = t["check"]
    if chk == "human":
        return "needs-human", t["question"]
    if chk == "spacing_in_set":
        allowed = set(t["allowed"])
        bad = [f"{p} = {l[t['prop']]}" for p, l in walk(d.get("layers")) if t["prop"] in l and l[t["prop"]] not in allowed]
        return ("fail", "; ".join(bad[:6])) if bad else ("pass", f"every {t['prop']} in {sorted(allowed)}")
    if chk == "max_kb":
        kb = d.get("html_kb")
        if kb is None:
            return "needs-human", "no html_kb in the design file: export the HTML and check its size"
        return ("pass" if kb <= t["max"] else "fail"), f"HTML is {kb} KB (limit {t['max']})"
    if chk == "alt_text":
        imgs = d.get("images", [])
        bad = [i.get("name", "?") for i in imgs if not (i.get("alt") or "").strip()]
        return ("fail", "missing alt: " + ", ".join(bad)) if bad else ("pass", f"{len(imgs)} images, all with alt")
    if chk == "links":
        links = d.get("links", [])
        bad = [l.get("label", "?") for l in links if not re.match(r"^https://\S+$", l.get("href") or "")]
        return ("fail", "broken or empty: " + ", ".join(bad)) if bad else ("pass", f"{len(links)} links, all https")
    if chk == "flag":
        v = d.get("checks", {}).get(t["key"])
        if v is None:
            return "needs-human", f"not recorded: {t['key']}"
        want = t.get("want", True)
        return ("pass" if v == want else "fail"), f"{t['key']} = {v}"
    if chk == "layer_names":
        bad = [p for p, l in walk(d.get("layers")) if DEFAULT_NAME.match(l.get("name", ""))]
        return ("fail", "default names: " + ", ".join(bad[:6])) if bad else ("pass", "every layer has a real name")
    if chk == "contrast":
        bad, n = [], 0
        for p, l in walk(d.get("layers")):
            if l.get("role") == t.get("role", "cta") and l.get("fill") and l.get("bg"):
                n += 1
                c = contrast(l["fill"], l["bg"])
                if c < t["min"]:
                    bad.append(f"{p} {c:.1f}:1")
        if not n:
            return "needs-human", "no CTA with fill and bg colours in the design file"
        return ("fail", "low contrast: " + ", ".join(bad)) if bad else ("pass", f"{n} CTA(s) at {t['min']}:1 or more")
    if chk == "min_font":
        bad = [f"{p} {l['mobile_font']}px" for p, l in walk(d.get("layers")) if "mobile_font" in l and l["mobile_font"] < t["min"]]
        return ("fail", "too small on mobile: " + ", ".join(bad[:6])) if bad else ("pass", f"mobile text {t['min']}px or more")
    return "needs-human", "unknown check"


def review(design, book):
    out = []
    for r in book.get("rules", []):
        status, evidence = run_check(r, design)
        out.append({"rule": r["id"], "kind": r["kind"], "statement": r["statement"], "status": status,
                    "evidence": evidence, "decision": "pending"})
    return out


def summary(findings):
    c = {s: sum(1 for f in findings if f["status"] == s) for s in ("pass", "fail", "needs-human")}
    hard_fail = [f["rule"] for f in findings if f["status"] == "fail" and f["kind"] == "hard"]
    return {"counts": c, "hard_fails": hard_fail,
            "ready_for_human": True,
            "note": "Draft review. Nothing was changed. A human accepts or rejects each finding."}


def main(a):
    if len(a) < 2:
        print(__doc__)
        return 2
    cmd = a[0]
    if cmd == "from-feedback":
        mn = int(a[a.index("--min") + 1]) if "--min" in a else 2
        with open(a[1], newline="", encoding="utf-8-sig") as f:
            rows = list(csv.DictReader(f))
        print(json.dumps({"drafts": from_feedback(rows, mn)}, indent=2, ensure_ascii=False))
        return 0
    if cmd == "lint":
        probs = lint(json.loads(Path(a[1]).read_text()))
        for rid, p in probs:
            print(f"{rid}: {p}")
        print("ok: every rule is testable" if not probs else f"{len(probs)} problem(s)")
        return 0 if not probs else 1
    if cmd == "review" and len(a) >= 3:
        book = json.loads(Path(a[2]).read_text())
        probs = lint(book)
        if probs:
            print("Fix the rulebook first (heuristics.py lint):", file=sys.stderr)
            for rid, p in probs:
                print(f"  {rid}: {p}", file=sys.stderr)
            return 1
        f = review(json.loads(Path(a[1]).read_text()), book)
        print(json.dumps({"summary": summary(f), "findings": f}, indent=2, ensure_ascii=False))
        return 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
