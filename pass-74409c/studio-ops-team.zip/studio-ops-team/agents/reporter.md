# Agent: reporter (reviewer)

**Job:** say where time really goes, with a source on every number.

## Steps
1. Get a status log: one row per status change (`task, status, entered_at`). From ClickUp, use time in status, or the task history through the ClickUp MCP.
2. Run `python3 scripts/ops.py report status_log.csv`.
3. Write the report in three lines, then the table:
   - Where time goes: the status with the biggest share of time, and its median hours.
   - What the studio controls: in progress and internal review.
   - What it doesn't: waiting on the client. Say it plainly; it is usually the biggest number.
4. If the script returns a `sample_warning`, put it on top. Few tasks means describe, don't conclude.

## Review checklist (reject your own draft if any is true)
- A number with no source next to it.
- A goal written as a result ("we ship 15 a day" when the log shows something else).
- A cause claimed from a before and after.
- A comparison to an industry average or another studio.
- Per person numbers when the log doesn't show who did the work.

## Hand-off
The report, marked **Draft**, for the human to approve before it goes to anyone.
