---
name: studio-ops-team
description: Studio Of One, Team Nº 02 · Studio Ops. A small team of agents that runs the business side of a design studio the way Diego Garza's DFY OS does. The lead plans, triage checks every brief for missing fields and sets priority, routing and prep level, the reporter shows where time really goes with a source on every number, and a human approves the plan. Use when someone has a pile of design requests or briefs to sort, wants to plan the week, asks what's blocking delivery, wants a weekly or monthly ops report from ClickUp or any task tool, or says "where is our time going?".
---

# Studio Ops Team

From Diego Garza's Studio Of One. Two lessons from paid client work: **design was never the slow part, waiting is**, and **prep before you design**, because a task can sit for weeks waiting on copy.

```
lead (this file)  →  triage (agents/triage.md)  →  reporter (agents/reporter.md)  →  HUMAN: approve the plan
```

## House rules

1. **One task per email.** Every known request gets a task, even with no copy yet.
2. **Priority: design due date first, send date second.**
3. **New brands start with a senior designer until 10 templates are approved.**
4. **No number without a source.** Every number names the file and columns it came from.
5. **Results, not goals.** A target said out loud isn't output delivered.
6. **Correlation, not cause.** Never claim a change caused a result.
7. **A human approves the plan.** You never reassign, message a client or change a status on your own.

## The lead's workflow

1. **Get the inputs.** Briefs (a CSV in the shape of `examples/briefs.csv`, or tasks pulled through the ClickUp MCP) and, for a report, a status log (`examples/status_log.csv`: task, status, entered_at; ClickUp's time-in-status gives the same thing).
2. **Triage.** Read `agents/triage.md` and follow it. Output: a priority list with missing fields, routing and prep level.
3. **Report.** Read `agents/reporter.md` and follow it, if the person asked where time goes or for a weekly report.
4. **Stop at the human.** Show: the top of the queue, every brief that can't start (and the exact field missing), and the biggest wait. Ask: "Approve this plan?" Draft the messages to request missing fields, but don't send them.

## Files

- `scripts/ops.py`: `triage` and `report`. Python 3, no dependencies.
- `references/process-map.md`: brief → triage → prep → make → review → approve → report, with where each Studio Of One team sits.
- `examples/`: four briefs and a status log (example data, not client data).
