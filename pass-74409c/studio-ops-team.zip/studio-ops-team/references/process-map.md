# The Studio Of One process map

How a request becomes an approved design, and where a team of agents sits at each step. A human closes every step.

| # | Step | What happens | Team |
|---|---|---|---|
| 1 | Brief | Every known email gets a task, even with no copy. Brand, type, topic, objective, CTA URL, design due, send date, copy status. | 02 Studio Ops · triage |
| 2 | Triage | Priority by design due date, then send date. New brands go to a senior until 10 templates are approved. Missing fields are requested, not guessed. | 02 Studio Ops · triage |
| 3 | Prep | P1 Match (closest approved email) or P2 Skeleton (brand, images, placeholder copy with word limits). | 08 Prep (in build) |
| 4 | Make | AI drafts the 90: layouts, variations. The designer owns the 10: brand fit and the business goal. | 04 Atomic, 07 Remix (04 built) |
| 5 | Review | The rulebook check, with evidence. A human accepts or rejects each finding. | 01 Heuristics · reviewer |
| 6 | Approve | The client reviews. Feedback that happens twice becomes a rule. | 01 Heuristics · rule-maker |
| 7 | Check the checker | How often does the AI reviewer agree with the human? Measured, not assumed. | 03 Model Review |
| 8 | Report | Where time goes, every number with its source. | 02 Studio Ops · reporter |

From Diego Garza's DFY OS 2.0 and the Template Prepping System SOP v2 (Oct 7, 2026).
